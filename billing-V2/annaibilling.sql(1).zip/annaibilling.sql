-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 13, 2017 at 10:39 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `annaibilling`
--

-- --------------------------------------------------------

--
-- Table structure for table `billingtable`
--

CREATE TABLE IF NOT EXISTS `billingtable` (
  `bill_id` int(100) NOT NULL AUTO_INCREMENT,
  `cust_address` varchar(200) NOT NULL,
  `dispatch_address` varchar(200) NOT NULL,
  `cust_code` varchar(100) NOT NULL,
  `cust_tax_reg_no` varchar(100) NOT NULL,
  `delivery_mode` varchar(100) NOT NULL,
  `payment_term` varchar(100) NOT NULL,
  `carrier` varchar(100) NOT NULL,
  `weight` varchar(100) NOT NULL,
  `product_desc` varchar(100) NOT NULL,
  `cust_order_ref` varchar(100) NOT NULL,
  `batch_no` varchar(100) NOT NULL,
  `qty` int(100) NOT NULL,
  `unit_price` decimal(10,4) NOT NULL,
  `total_value` decimal(10,4) NOT NULL,
  `trade_disc` decimal(10,4) NOT NULL,
  `add_disc` decimal(10,4) NOT NULL,
  `cum_duty_value` decimal(10,4) NOT NULL,
  `tax` decimal(10,4) NOT NULL,
  `tax_value` decimal(10,4) NOT NULL,
  `total_value_of_goods` decimal(10,4) NOT NULL,
  `total_trade_disc` decimal(10,4) NOT NULL,
  `total_add_disc` decimal(10,4) NOT NULL,
  `total_cum_duty_value` decimal(10,4) NOT NULL,
  `final_amount_payable` decimal(10,4) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(100) NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`bill_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `billingtable`
--

INSERT INTO `billingtable` (`bill_id`, `cust_address`, `dispatch_address`, `cust_code`, `cust_tax_reg_no`, `delivery_mode`, `payment_term`, `carrier`, `weight`, `product_desc`, `cust_order_ref`, `batch_no`, `qty`, `unit_price`, `total_value`, `trade_disc`, `add_disc`, `cum_duty_value`, `tax`, `tax_value`, `total_value_of_goods`, `total_trade_disc`, `total_add_disc`, `total_cum_duty_value`, `final_amount_payable`, `created_date`, `status`) VALUES
(13, 'vvv', 'vvv', '', '545', 'bvvb', 'bbb', 'vbcv', '34', 'dfgdf', '34534', '45', 1, '333.0000', '0.0000', '0.0000', '0.0000', '0.0000', '14.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '2016-12-02 15:07:38', 'Active'),
(14, 'vvv', 'vvv', '', '545', 'bvvb', 'bbb', 'vbcv', '34', 'dfgdf', '34534', '45', 1, '333.0000', '0.0000', '0.0000', '0.0000', '0.0000', '14.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '2016-12-02 15:13:19', 'Active'),
(15, 'vvv', 'vvv', '', '545', 'bvvb', 'bbb', 'vbcv', '34', 'dfgdf', '34534', '45', 1, '333.0000', '0.0000', '0.0000', '0.0000', '0.0000', '14.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '2016-12-02 15:14:14', 'Active'),
(16, 'czxc', 'xczxc', '', 'dfs', 'dfs', 'df', 'df', '2', 'df', 'sdf', '34', 1, '333.0000', '0.0000', '0.0000', '0.0000', '0.0000', '14.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '2016-12-02 15:15:02', 'Active'),
(17, 'bcv', 'vcb', '', 'vcbv', 'cvb', 'cvb', 'cvb', '78', 'fg', 'fg', '345', 5, '333.0000', '0.0000', '0.0000', '0.0000', '0.0000', '14.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '2016-12-02 15:15:42', 'Active'),
(18, 'dsfs', 'hgj', '', '24', 'dfgh', 'hfj', 'ju', '4', 'ukk', 'fh', '5', 1, '333.0000', '333.0000', '0.0000', '0.0000', '0.0000', '14.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '2016-12-02 15:34:56', 'Active'),
(19, 'kolar', 'hoskote', '', 'tax34', 'online', 'netbanking', 'hjk', '50', 'hjkll', 'ref4', '1', 10, '110.0000', '1100.0000', '0.0000', '0.0000', '0.0000', '14.5000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '2016-12-02 16:34:13', 'Active'),
(20, 'kkkkkk', 'hhhhh', '', 't6', 'fff', 'home', 'vhhh', '59', 'bnmjk', 're3', '2', 20, '220.0000', '4400.0000', '0.0000', '0.0000', '0.0000', '14.5000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '2016-12-02 16:36:27', 'Active'),
(21, 'jollajhj', 'bnsdgf', '', 'vdbghjgd,', 'hjkgjwgb', 'effjhfn', 'dg', '78', 'ghjgf', 'gjbkjhn', '5', 30, '330.0000', '9900.0000', '0.0000', '0.0000', '0.0000', '14.5000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '2016-12-02 16:39:14', 'Active'),
(22, 'gfmdbj', 'fhsdjgnm', '', 'dngjkhlf', 'jkkhhjk', 'lllll', 'kkkk', '66', 'hhhhhhh', 'dsfbkgn', '6', 40, '440.0000', '17600.0000', '0.2000', '0.0000', '0.0000', '14.5000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '2016-12-02 16:41:59', 'Active'),
(23, 'jdjkjhjh', 'kkjhjjkkl', '', 'fghj', 'kkkkl', 'jkkuuvf', 'dfhghjjk', 'gfsdgjh', 'ghhjjkk', '78u', '5', 5, '550.0000', '2750.0000', '0.2000', '0.0000', '0.0000', '14.5000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '2016-12-02 16:44:15', 'Active'),
(24, 'hgfjhhj', 'kjh', '', 'hg6', 'jhjh', '7g', 'hjh', '59', 'hjhj', 'r4', '4', 6, '100.0000', '600.0000', '0.2000', '0.0000', '0.0000', '14.5000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '2016-12-02 16:47:18', 'Active'),
(25, 'hjbnn', 'gvhfgh', '', 'dftt', 'cvghg', 'ggh', 'gh', '56', 'gfghhj', 'fgdfd', '44', 1, '200.0000', '200.0000', '0.2000', '0.0000', '0.0000', '14.5000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '0.0000', '2016-12-02 16:50:58', 'Active'),
(26, 'mgg', 'fgh', '', 'bbbb', 'xgff', 'gfg', 'b', '45', 'gfhg', 'hgh5', '4', 1, '400.0000', '400.0000', '0.2000', '0.0000', '0.0000', '14.5000', '0.0000', '0.0000', '320.0000', '0.0000', '0.0000', '0.0000', '2016-12-02 16:59:45', 'Active'),
(27, 'gggg', 'hhhh', '', '34', 'jjjjj', 'kkkkk', 'lllll', '20', 'aaaa', 'bbbb', '56', 7, '700.0000', '4900.0000', '0.2000', '0.0000', '0.0000', '14.5000', '0.0000', '0.0000', '560.0000', '0.0000', '0.0000', '0.0000', '2016-12-05 11:10:47', 'Active'),
(28, 'gggg', 'hhhh', '', '34', 'jjjjj', 'kkkkk', 'lllll', '20', 'aaaa', 'bbbb', '56', 7, '700.0000', '4900.0000', '0.2000', '0.0000', '0.0000', '14.5000', '0.0000', '0.0000', '560.0000', '532.0000', '0.0000', '0.0000', '2016-12-05 11:13:46', 'Active'),
(29, 'gggg', 'hhhh', '', '34', 'jjjjj', 'kkkkk', 'lllll', '20', 'aaaa', 'bbbb', '56', 7, '700.0000', '4900.0000', '0.2000', '0.0000', '0.0000', '14.5000', '0.0000', '0.0000', '560.0000', '532.0000', '0.0000', '0.0000', '2016-12-05 11:13:50', 'Active'),
(30, 'aaaa', 'bbbb', '', '33333', 'ccccc', 'dddd', 'eeee', '34', 'fffff', 'ggg56', '3', 1, '100.0000', '100.0000', '0.2000', '0.0000', '0.0000', '14.5000', '0.0000', '0.0000', '80.0000', '76.0000', '0.0000', '0.0000', '2016-12-05 11:14:43', 'Active'),
(31, 'ghfj', 'jhj', '', 'hjjf', 'm mbvhk', 'kkkkjh', 'jhj', '8', 'hjdfj', 'jfxnjyhg', '7gfnj', 3, '100.0000', '300.0000', '0.2000', '0.0000', '-20.9607', '14.5000', '-3.0393', '0.0000', '80.0000', '76.0000', '0.0000', '0.0000', '2016-12-05 16:49:10', 'Active'),
(32, 'ghfj', 'jhj', '', 'hjjf', 'm mbvhk', 'kkkkjh', 'jhj', '8', 'hjdfj', 'jfxnjyhg', '7gfnj', 3, '100.0000', '300.0000', '0.2000', '0.0000', '-20.9607', '14.5000', '-3.0393', '0.0000', '80.0000', '76.0000', '0.0000', '0.0000', '2016-12-05 16:52:21', 'Active'),
(33, 'ssss', 'dddd', '', 'teleorder', 'order', 'without deduction', 'none', '20', 'jkghdk', 'svnmnb', '201508', 1, '335.0000', '335.0000', '0.2000', '0.0000', '-70.2183', '14.5000', '-10.1817', '0.0000', '268.0000', '254.6000', '0.0000', '0.0000', '2016-12-05 16:54:04', 'Active'),
(34, 'dhsfh', 'fhfh', '', 'cnnhjgj', 'nfhhh', ' mbmjv', ' bvjj', '5', 'jugfjh', 'gfxju', 'xftuu', 1, '335.0000', '335.0000', '0.2000', '0.0000', '222.3581', '14.5000', '32.2419', '0.0000', '268.0000', '254.6000', '0.0000', '0.0000', '2016-12-05 16:58:50', 'Active'),
(35, 'gsdh', 'xcbg', '', 'bmhj', 'ghhh', 'ghjj', 'jjj', '89', 'vhhh', 'gfhh', '7', 1, '1613.0000', '1613.0000', '0.2000', '0.0000', '1070.6376', '14.5000', '155.2424', '0.0000', '1290.4000', '1225.8800', '0.0000', '0.0000', '2016-12-05 17:01:35', 'Active'),
(36, '', '', '', '', '', '', '', '', '', '', '', 2, '100.0000', '200.0000', '0.2000', '0.0000', '66.3755', '12.5000', '8.2969', '0.0000', '80.0000', '76.0000', '0.0000', '0.0000', '2017-01-10 13:10:32', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `form`
--

CREATE TABLE IF NOT EXISTS `form` (
  `product_id` int(100) NOT NULL AUTO_INCREMENT,
  `battery_sap_code` varchar(100) NOT NULL,
  `ah_rating` varchar(100) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `form`
--

INSERT INTO `form` (`product_id`, `battery_sap_code`, `ah_rating`, `brand`, `price`, `created_date`) VALUES
(1, 'DBI0-12BI2.5L-C', '2.5', 'Exide Bikerz', '828', '2017-01-13 15:08:54'),
(2, 'DBI0-12BI5L-B', '5.0', 'Exide Bikerz', '1216', '2017-01-13 15:09:22'),
(3, 'DBI0-12BI7B-B', '7.0', 'Exide Bikerz', '1349', '2017-01-13 15:10:57'),
(4, 'DBI0-12BI9-B', '9.0', 'Exide Bikerz', '1727', '2017-01-13 15:11:40'),
(5, 'DBI0-12BI14L-A2', '14.0', 'Exide Bikerz', '3048', '2017-01-13 15:12:30'),
(6, 'FXL0-XLTZ3', '3.0', 'Exide Xplore', '1013', '2017-01-13 15:21:21'),
(7, 'FXL0-XLTZ4', '3.0', 'Exide Xplore', '1147', '2017-01-13 15:21:53'),
(8, 'FXL0-XLTZ5', '4.0', 'Exide Xplore', '1408', '2017-01-13 15:22:22'),
(9, 'FXL0-XLTZ7', '6.0', 'Exide Xplore', '1862', '2017-01-13 15:23:08'),
(10, 'FXR0-12XR2.5L-C', '2.5', 'Exide Xtreme', '957', '2017-01-13 15:24:15'),
(11, 'FXR0-12XR5-L-B', '5.0', 'Exide Xtreme', '1404', '2017-01-13 16:16:57'),
(12, 'FXR0-12XR7B-B', '7.0', 'Exide Xtreme', '1530', '2017-01-13 16:17:52'),
(13, 'FXR0-12XR9-B', '9.0', 'Exide Xtreme', '1995', '2017-01-13 16:18:36'),
(14, 'FSK0-SKTZ4', '3.0', 'Exide Skutec', '1147', '2017-01-13 16:19:30'),
(15, 'FSK0-SKTZ5', '4.0', 'Exide Skutec', '1408', '2017-01-13 16:19:59');
